//
//  HangmanState.swift
//  Hangman
//
//  Created by Lauren Go on 2020/09/29.
//

import Foundation

class HangmanViewModel : ObservableObject {
    @Published var currentLevel : Int = 1
    @Published var IncorrectGuesses : Int = 0
    @Published var IncorrectList : String = String()
    @Published var currentStatus : [Character] = []
    @Published var gameStatus : Bool = false
    @Published var curStr : String = String()
    @Published var darkMode : Bool = false
    @Published var hintChance : Int = 0
    @Published var detailed : Bool = false
    @Published var funny1 : Bool = false
    
    let phrasesList : [[String]] = [
        ["Jun is my son", "Jun is my grandSon", "Im father of Jun"],
        ["Washington", "Biden", "Donald Trump", "Voting now", "Democracy", "Republican", "Congress"],
        ["abash", "concomitant", "defunct", "recrimination", "zenith", "quench", "notorious", "rupture",
        "saga", "tired"],
        ["aberration", "amorphous", "apocryphal", "camaraderie", "cupidity", "embezzlement", "grandiloquent", "largesse", "neophyte", "pejorative"]
    ]
    
    var currentPhrase : String = ""
    
    var phrases : [String] = []
    /** Initializes a new game. */
    init() {
        restart()
    }
    
    /** Resets model properties to restart game. */
    func restart() {
        phrases = phrasesList[self.currentLevel - 1]
        self.currentPhrase = phrases.randomElement() ?? "no"
        self.IncorrectGuesses = 0
        self.IncorrectList = String()
        self.currentStatus = constructStatus(curPhrase : currentPhrase)
        self.gameStatus = false
        self.hintChance = 1000
        self.detailed = false
        update()
    }
    /** Increments word level*/
    func incrementLevel() {
        if currentLevel == 4 {
            return
        } else {
            currentLevel += 1
            restart()
        }
    }
    /** Decrements word level*/
    func decrementLevel() {
        if currentLevel == 1 {
            return
        } else {
            currentLevel -= 1
            restart()
        }
    }
    /** Construct current status*/
    func constructStatus(curPhrase : String) -> [Character] {
        var res : [Character] = []
        for char in curPhrase {
            if char == " " {
                res.append(char)
            } else {
                res.append("-")
            }
            
        }
        return res
    }
    /** get the a hint, randomly distributed in cur phrase*/
    func getHint() {
        if (self.hintChance == 0) {
            return
        }
        var a : [Int] = []
        self.hintChance -= 1
        for i in 0...currentStatus.count - 1 {
            if currentStatus[i] == "-" {
                a.append(i)
            }
        }
        let ranInt : Int = a.randomElement()!
        let res : String = currentPhrase[currentPhrase.index(currentPhrase.startIndex, offsetBy: ranInt)].uppercased()
        currentStatus[ranInt] = res[res.startIndex]
        update()
        if (didWin()) {
            gameStatus = true
        }
    }
    /**
     Checks if the game has reached a lose state.
     - Returns: A Boolean for if the user won or not and has guesses left.
     */
    public func didLose() -> Bool {
        return IncorrectGuesses == 6
    }
    
    /**
     Checks if the game has reached a win state.
     - Returns: A Boolean for if the user won or not and has guesses left.
     */
    public func didWin() -> Bool {
        return IncorrectGuesses < 6 && !currentStatus.contains("-")
    }
    
    /**
     Processes the user's guess.
     - Parameter guess letter: Character for the letter that is being guessed.
     */
    func makeGuess(guess letter: Character) {
        if (IncorrectList.contains(letter)) {
            return
        }
        let c = inside(str: currentPhrase, char: letter)
        if c != -1 {
            currentStatus[c] = letter
            update()
            if didWin() {
                gameStatus = true
            }
        } else {
            IncorrectList.append(letter)
            IncorrectGuesses += 1
            if didLose() {
                gameStatus = true
            }
        }
    }
    
    /**
        Update current status
     */
    func update() {
        curStr.removeAll()
        for char in currentStatus {
            curStr.append(char)
        }
    }
    
    /**
        Check if the char is inside of cur phrase, if it is, return a non negative one index
     */
    func inside(str : String, char : Character) -> Int {
        for i in 0...str.count - 1 {
            let a = str[str.index(str.startIndex, offsetBy: i)]
            let b = currentStatus[i]
            if a.lowercased() == char.lowercased() && b == "-" {
                return i
            }
        }
        return -1
    }
    
    /**
        Get the word's detail message
     */
    public func getDetailMessage() -> String {
        if currentLevel == 1 {
            return "Jun's identity"
        } else if currentLevel == 2 {
            return "Vote Now!"
        } else if currentLevel == 3 {
            return "Medium level SAT words"
        } else {
            return "Hard level SAT words"
        }
    }
    /**
     Returns a message to notify the winner if they won or not
     - Returns: Message depending on whether they won or not
     */
    public func getFinalMessage() -> String {
        // TODO: Check the game state using the didWin/didLose functions and return an appropriate string.
        if didWin() {
            return "You won the game!"
        } else {
            return "You lost, the correct word is \(self.currentPhrase)"
        }
    }
    
    
    
}
