//
//  ContentView.swift
//  Hangman
//
//  Created by Lauren Go on 2020/09/29.
//

import SwiftUI
enum KeyboardButton: String {
    case A, B, C, D, E, F, G, H, I, J, K, L, M,
         N, O, P, Q, R, S, T, U, V, W, X, Y, Z
    
}
struct ContentView: View {
    
    @EnvironmentObject var environment : HangmanViewModel
    
    //KeyBoard setups
    let buttonValues: [[KeyboardButton]] = [
        [.A, .B, .C, .D, .E, .F, .G],
        [.H, .I, .J, .K, .L, .M, .N],
        [.O, .P, .Q, .R, .S, .T, .U],
        [.V, .W, .X, .Y, .Z]
    ]
    var body: some View {
        VStack {
            HStack {
                //DarkMode option
                Button(action: {
                    self.environment.darkMode.toggle()
                }, label: {
                    Text(!self.environment.darkMode ? "DarkMode" : "SunlightMode").font(.system(size : Hangman.font())).padding(.leading, 15).foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                })
                Spacer()
                //Restart option
                Button(action: {
                    self.environment.restart()
                }, label: {
                    Text("Restart").font(.system(size : Hangman.font())).padding(.trailing, 15).foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                })
            }.padding(.top)
            if self.environment.darkMode {
                Image("image").resizable().frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 20).padding(.top, 0)
            } else {
                Image("title_13").resizable().frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 20).padding(.top, 0)
            }
            // hangman image
            Button(action : {
                self.environment.funny1.toggle()
            }, label: {
                Text("Funny Hangman Choice: \(forGirl(b: environment.funny1))").font(.system(size: Hangman.font()))
            })
            if self.environment.funny1 {
                Image("hangmanfunny\(self.environment.IncorrectGuesses)\(self.environment.IncorrectGuesses)").resizable().frame(width: UIScreen.main.bounds.width / 3, height: UIScreen.main.bounds.height / 5)} else {
                Image("hangmanfunny\(self.environment.IncorrectGuesses)").resizable().frame(width: UIScreen.main.bounds.width / 3, height: UIScreen.main.bounds.height / 5)}
            HStack {
                //stepper for word level
                Stepper(onIncrement: {
                    self.environment.incrementLevel()
                }, onDecrement: {
                    self.environment.decrementLevel()
                }) {
                    Text("Word Level").font(.system(size: Hangman.font())).padding().foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                }
                Spacer()
                //hint button
                Button (action: {
                    self.environment.getHint()
                }, label: {
                    Text("Hint Chance: \(self.environment.hintChance)").font(.system(size : Hangman.font())).padding().foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                }).disabled(self.environment.gameStatus)
            }
            HStack {
                //hint info
                Button(action: { self.environment.detailed.toggle()
                }, label: {
                    Text("What's in words?").font(.system(size: Hangman.font())).foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                }).padding()
                Spacer()
                if self.environment.detailed {
                    Text(self.environment.getDetailMessage()).font(.system(size: Hangman.font())).padding().foregroundColor(environment.darkMode ? .white : /*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                }
            }            // Current String that we have
            Text(environment.curStr)
                .font(.system(size: Hangman.font()))
                .foregroundColor(self.environment.darkMode ? Color.white : Color.black)
            HStack {
                // incorrect guesses list
                Text("Incorrect guesses:")
                    .font(.system(size: Hangman.font()))
                    .padding(.leading)
                    .foregroundColor(self.environment.darkMode ? Color.white : Color.black)
                Text(self.environment.IncorrectList)
                    .font(.system(size: Hangman.font()))
                    .foregroundColor(self.environment.darkMode ? Color.white : Color.black)
                Spacer()
            }
            Spacer()
            ForEach(buttonValues, id: \.self) { row in
                HStack {
                    ForEach(row, id: \.self) { button in
                        KeyBoardButtonView(button : button)
                    }
                }
            }.padding(.bottom, 10)
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height).padding().background(self.environment.darkMode ? Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)) : Color.white).alert(isPresented: $environment.gameStatus) {
            Alert(title: Text("Game Ends"), message: Text(self.environment.getFinalMessage()), dismissButton: .default(Text("restart"), action: {
                self.environment.restart()
            }))}
    }
}
// A function for choosing image
func forGirl(b : Bool) -> String {
    return b ? "For Boy" : "For Girl"
}

func font() -> CGFloat {
    return (UIScreen.main.bounds.width - 7 * 10) / 20
}
// KeyBoardButton View.
struct KeyBoardButtonView: View {
    
    @EnvironmentObject var environment : HangmanViewModel
    
    var button : KeyboardButton
    var body : some View {
        Button(action: {
                self.environment.makeGuess(guess: button.rawValue[button.rawValue.startIndex])
        },
        label: {
            Text(button.rawValue)
                .font(.system(size: Hangman.font()))
                .frame(width: self.buttonWidth(button : button), height: self.buttonHeight())
                .foregroundColor(self.environment.gameStatus ? .gray : self.environment.darkMode ? .white : .red)
                .background(self.environment.darkMode ? Color.black.cornerRadius(20).shadow(radius: 5) :
                    Color.white.cornerRadius(20).shadow(radius: 5))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.red))
        })
    }
    //button width relates to UIScreen width
    func buttonWidth(button : KeyboardButton) -> CGFloat {
        let special = ["V", "W", "X", "Y", "Z"]
        if special.contains(button.rawValue) {
            return (UIScreen.main.bounds.width - 5 * 10) / 5
        }
        return (UIScreen.main.bounds.width - 7 * 10) / 7
    }
    //button height relates to UIScreen height
    func buttonHeight() -> CGFloat {
        return (UIScreen.main.bounds.width - 7 * 10) / 7
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(HangmanViewModel())
    }
}
