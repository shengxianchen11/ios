//
//  HangmanApp.swift
//  Hangman
//
//  Created by Lauren Go on 2020/09/29.
//

import SwiftUI

@main
struct HangmanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(HangmanViewModel())
        }
    }
}
