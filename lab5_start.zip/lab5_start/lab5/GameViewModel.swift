//
//  GameViewModel.swift
//  lab5
//
//  Created by Arman Vaziri on 10/12/20.
//

import Foundation

class GameViewModel: ObservableObject {
    @Published var displayWord: String = ""
    @Published var correctGuesses: Int = 0
    @Published var incorrectGuesses: Int = 0
    @Published var gameOver: Bool = false
    
    let words1: [String] = ["bat", "owl", "ghost"]
    let words2: [String] = ["moon", "corn", "star"]
    let words3: [String] = ["candy", "mummy", "witch"]
    var word: String!
    var words: [String]!
    
    init() {
        restart()
    }
    
    /*
     Restarts the game state.
     */
    func restart() {
        self.words = self.randomArr()
        self.word = self.words.randomElement()
        self.displayWord = String(word.map{_ in Character("-")})
        self.correctGuesses = 0
        self.incorrectGuesses = 0
        self.gameOver = false
    }
    
    /*
     Select one of the three arrays to be used for the round. The 
     */
    func randomArr() -> [String] {
        let number = Int.random(in: 1...3)
        switch number {
        case 3: return self.words1
        case 4: return self.words2
        default: return self.words3
        }
    }

    /*
     Replaces a "-" in the display word with the appropriate letter.
     */
    func fillHint() {
        let charArr = Array(self.word)
        var displayTemp = Array(displayWord)
        var index = 0
        for char in displayWord {
            if char == "-" {
                displayTemp[index] = charArr[index]
                self.displayWord = String(displayTemp)
                break
            } else {
                index += 1
            }
        }
    }
    
    /*
     Processes a user's word guess.
     */
    func processWordGuess(word: String) {
        if word == self.word {
            self.correctGuesses += 1
            if self.correctGuesses == 5 {
                gameOver.toggle()
            } else {
                newWord()
            }
        } else {
            self.incorrectGuesses += 1
            if self.incorrectGuesses == 5 {
                gameOver.toggle()
            }
        }
    }
    
    /*
     Changes the word in question.
     */
    func newWord() {
        self.words = self.randomArr()
        self.word = self.words.randomElement()
        self.displayWord = String(word.map{_ in Character("-")})
    }
    
    /*
     Returns a final message for the alert depending on the final game state
     */
    func getFinalMessage() -> String{
        return self.correctGuesses == 5 ? "You win!" : "Try again!"
    }
    
}
