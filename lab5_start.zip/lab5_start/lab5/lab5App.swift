//
//  lab5App.swift
//  lab5
//
//  Created by Arman Vaziri on 10/12/20.
//

import SwiftUI

@main
struct lab5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(GameViewModel())
        }
    }
}
