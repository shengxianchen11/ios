//
//  ContentView.swift
//  lab5
//
//  Created by Arman Vaziri on 10/12/20.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var env : GameViewModel
    
    var body: some View {
        VStack {
            HStack {
                VStack {
                    Text("Correct: \(self.env.correctGuesses)")
                    Text("Incorrect: \(self.env.incorrectGuesses)").padding(.leading)
                }.padding(.top)
                Spacer()
                Button(action: {self.env.restart()}, label: {
                    Text("restart").padding(.trailing).foregroundColor(.orange)
                }).padding(.top)
            }.frame(width: UIScreen.main.bounds.width, alignment: .leading)
            Image("witch").resizable().frame(width: UIScreen.main.bounds.width / 2, height: UIScreen.main.bounds.height / 3, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Text(self.env.displayWord).font(.largeTitle)
            Text("Choose the right words").font(.system(size: 20)).padding(UIScreen.main.bounds.width / 12)
            Button(action: {self.env.fillHint()}, label: {
                Text("hint").foregroundColor(.orange)
            })
            Spacer()
            ForEach(self.env.words, id: \.self) { button in
                HStack {
                    WordButtonView(word : button)
                }
            }.padding(.bottom, UIScreen.main.bounds.width / 20 - 10)
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height).padding().alert(isPresented: $env.gameOver) {
            Alert(title: Text("Game Ends"), message: Text(self.env.getFinalMessage()), dismissButton: .default(Text("restart"), action: {
                self.env.restart()
            }))}
    }
}


struct WordButtonView: View {
    
    @EnvironmentObject var env : GameViewModel
    var word : String
    var body: some View {
        Button(action: {self.env.processWordGuess(word: word)}, label: {
            Text(word).padding().frame(width: UIScreen.main.bounds.width / 1.5, height: UIScreen.main.bounds.height / 15 - 10, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).foregroundColor(.orange).background(Color.black).font(.system(size: getfont()))
        })
    }
}

func getfont() -> CGFloat {
    return UIScreen.main.bounds.width / 20
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(GameViewModel())
    }
}

/*
 The struct we'll use to display words as buttons that the user can select as a guess.
 */

