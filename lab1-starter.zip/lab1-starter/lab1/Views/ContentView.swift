//  ContentView.swift
//  lab1 - Stacks
//
//  Copyright © 2020 ios decal. All rights reserved.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
         VStack (alignment: .leading) {
            
            /* TODO: Create a View with "COVID Tracker" title and Country View within an HStack. You should play around with Spacers.
               * Optional: Add Top and Bottom Padding
               * Optional: Give Your title a custom font. See "Are you feeling sick?" below.
            */
            
            HStack {
                Text("Covid-19").bold()
                    .font(.system(size: 20, weight: .medium, design:
                    .rounded))
                Spacer()
                Image(systemName: "flag.circle")
                Text("USA").foregroundColor(Color(#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)))
            }
            // MARK: Section 2
            Text ("Are you feeling sick?")
               .font(.system(size: 14, weight: .medium, design: .rounded))
               .modifier(VPadding(size: 10))
            
            /* TODO: Create a placeholder Text view. Use the following Modifiers to make it fancy.
            */
            
            /* TODO: Modify the font and add Top and Bottom Padding. Change the font color to something lighter.
             */
            Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse est leo, vehicula eu eleifend non, auctor ut arcu")
                .fixedSize(horizontal: false, vertical: true).font(.system(size: 14, weight: .medium, design: .rounded)).foregroundColor(Color(#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1))).modifier(VPadding(size: 10))
         
            HStack {
               
               /* TODO: Create another button using ContactButtonView.
                * It should say "Call now" and use the SF Glyph "phone.fill". Make it whatever color you want.
                */
               
               // TODO: Gray is a bit dull. Change it to a different color.
                ContactButtonView(backgroundColor: Color(#colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)), sfGlyph: "phone.fill", description: "Call Now")
               ContactButtonView(backgroundColor: Color.blue,
                                 sfGlyph: "square.and.pencil",
                                 description: "Send iMessage")
            }
         }
         .padding(.leading, 10)
         .padding(.trailing, 10)
      }
}

// This View is reusable. How do you pass arguments into Views?
struct ContactButtonView: View {
   
   var backgroundColor: Color
   var sfGlyph: String        //e.g. "phone.fill"
   var description: String    //e.g. "Call Now"
   var height: CGFloat = 50
   
   var body: some View {
      ZStack {
         RoundedRectangle(cornerRadius: 10, style: .continuous)
            .foregroundColor(backgroundColor)
         HStack {
            Image(systemName: sfGlyph)
            Text(description)
         }
         .foregroundColor(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
      }
      .frame(height: height)
   }
}


struct VPadding: ViewModifier {
   // We are constnatly padding both the bottom and the top. Why not just do it together at once.
   // Is it better to pass in absolute, or relative padding?
   
   let size: CGFloat
   
   func body(content: Content) -> some View {
      content
         .padding(.top, size)
         .padding(.bottom, size)
   }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
         .previewDevice(PreviewDevice(rawValue: "iPhone 11 Pro"))
//      ContentView()
//         .previewDevice(PreviewDevice(rawValue: "iPad Pro (11-inch)"))
         // Text("This is a view too!")
      
    }
}
